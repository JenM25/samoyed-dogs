# Blog of Song Kong
This is a Jekyll theme called Ice bear.

To learn how to install and use this theme, please check out the [installation guide](http://ikongsong.com/blog/ice-bear-jekyll-theme/) for more information.

## License
This theme is open source under MIT License. So feel free to use this Jekyll theme on your site, although linking back to me is more than welcomed.
